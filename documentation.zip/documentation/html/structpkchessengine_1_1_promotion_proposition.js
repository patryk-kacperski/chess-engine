var structpkchessengine_1_1_promotion_proposition =
[
    [ "PromotionProposition", "structpkchessengine_1_1_promotion_proposition.html#ab0ec5a6a34880eca724625990c24e636", null ],
    [ "PromotionProposition", "structpkchessengine_1_1_promotion_proposition.html#aaad8ebfb44fbb4e8c8d64f486e6697cd", null ],
    [ "position", "structpkchessengine_1_1_promotion_proposition.html#a90c140e2cbd2167b52bea13fd80df9ef", null ],
    [ "shouldPromote", "structpkchessengine_1_1_promotion_proposition.html#a82841497ac0900b588408e88bf0ebab4", null ]
];