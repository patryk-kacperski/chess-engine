var _move_result_8h =
[
    [ "MoveResult", "_move_result_8h.html#aa909bb6eb3b8f00568f0a4ffe1946e9b", [
      [ "kValid", "_move_result_8h.html#aa909bb6eb3b8f00568f0a4ffe1946e9ba4d3576c37e6f03700bad4345238fffa0", null ],
      [ "kGameIsOver", "_move_result_8h.html#aa909bb6eb3b8f00568f0a4ffe1946e9ba98be15334af6db287e02aae7a626e118", null ],
      [ "kPromotionShouldBePerformed", "_move_result_8h.html#aa909bb6eb3b8f00568f0a4ffe1946e9ba0cc634695eed05e17e79040b36e02098", null ],
      [ "kOutOfBoard", "_move_result_8h.html#aa909bb6eb3b8f00568f0a4ffe1946e9ba110002bdcccdc413aeaafd2727ca36e8", null ],
      [ "kNoPieceAtOrigin", "_move_result_8h.html#aa909bb6eb3b8f00568f0a4ffe1946e9ba3d35f471408d8608d5d6869f1b93ae5a", null ],
      [ "kWrongSidePieceAtOrigin", "_move_result_8h.html#aa909bb6eb3b8f00568f0a4ffe1946e9ba41703b7a40123e83d4d6fbf2ded61a78", null ],
      [ "kFriendlyPieceAtDestination", "_move_result_8h.html#aa909bb6eb3b8f00568f0a4ffe1946e9bab443b5e048e7c9a2358d3e4a0d3fcb16", null ],
      [ "kIllegal", "_move_result_8h.html#aa909bb6eb3b8f00568f0a4ffe1946e9ba8477ecd90bfaa59c0f3adb1fef510a5c", null ],
      [ "kExposesKing", "_move_result_8h.html#aa909bb6eb3b8f00568f0a4ffe1946e9ba2643c9bac6f9d8de280a13f90674cac1", null ],
      [ "kPathBloceked", "_move_result_8h.html#aa909bb6eb3b8f00568f0a4ffe1946e9bae6e356b1f63d4a92ea7a09d948e5efd0", null ],
      [ "kInvalidAlgebraicNotation", "_move_result_8h.html#aa909bb6eb3b8f00568f0a4ffe1946e9ba42688a284d183cbbdf81474c9908df6e", null ]
    ] ]
];