var _piece_type_8h =
[
    [ "PieceType", "_piece_type_8h.html#a944a1fb497e86ffc347afdb3f0f84381", [
      [ "kPawn", "_piece_type_8h.html#a944a1fb497e86ffc347afdb3f0f84381a5187644c2338a06f6ac916ab31c64ea9", null ],
      [ "kRook", "_piece_type_8h.html#a944a1fb497e86ffc347afdb3f0f84381abdd7c9b6be196c66eb64f17ad5ed446f", null ],
      [ "kBishop", "_piece_type_8h.html#a944a1fb497e86ffc347afdb3f0f84381ac082ad689c95af3e260b698b6288104a", null ],
      [ "kKnight", "_piece_type_8h.html#a944a1fb497e86ffc347afdb3f0f84381a69ac08d402267ebb8f8ed16252a29431", null ],
      [ "kKing", "_piece_type_8h.html#a944a1fb497e86ffc347afdb3f0f84381aace1f8d5899e0335f727b664001dd6b2", null ],
      [ "kQueen", "_piece_type_8h.html#a944a1fb497e86ffc347afdb3f0f84381a29102b2d5303ff2b486596436e7b4030", null ],
      [ "kNone", "_piece_type_8h.html#a944a1fb497e86ffc347afdb3f0f84381a35c3ace1970663a16e5c65baa5941b13", null ]
    ] ]
];