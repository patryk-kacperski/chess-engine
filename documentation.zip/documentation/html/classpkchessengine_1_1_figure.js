var classpkchessengine_1_1_figure =
[
    [ "validate", "classpkchessengine_1_1_figure.html#a5889f6dd9e84c956840ddd680a9ba013", null ]
];