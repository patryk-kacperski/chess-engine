var _promotion_result_8h =
[
    [ "PromotionResult", "_promotion_result_8h.html#a4e36317122fe119d040920d5cad75837", [
      [ "kValid", "_promotion_result_8h.html#a4e36317122fe119d040920d5cad75837a4d3576c37e6f03700bad4345238fffa0", null ],
      [ "kOutOfBoard", "_promotion_result_8h.html#a4e36317122fe119d040920d5cad75837a110002bdcccdc413aeaafd2727ca36e8", null ],
      [ "kWrongPosition", "_promotion_result_8h.html#a4e36317122fe119d040920d5cad75837a83cb8349a35c940f7e1417930300610a", null ],
      [ "kNoPiece", "_promotion_result_8h.html#a4e36317122fe119d040920d5cad75837ac93ab4691d8ff128b8ffb3c3b359a7d4", null ],
      [ "kPieceIsNotPawn", "_promotion_result_8h.html#a4e36317122fe119d040920d5cad75837ad0f0bbc29890da90e04f364c83076eb1", null ],
      [ "kWrongSide", "_promotion_result_8h.html#a4e36317122fe119d040920d5cad75837a0247a6eec04dffda7c31db84e8248dab", null ],
      [ "kInvalidType", "_promotion_result_8h.html#a4e36317122fe119d040920d5cad75837a9a330e6a158f415f9fce371be1d94653", null ]
    ] ]
];