var dir_996f45160da62e1a3d7f6046fad68f51 =
[
    [ "ChessEngine.cpp", "_chess_engine_8cpp.html", null ],
    [ "ChessEngine.h", "_chess_engine_8h.html", [
      [ "ChessEngine", "classpkchessengine_1_1_chess_engine.html", "classpkchessengine_1_1_chess_engine" ]
    ] ],
    [ "ChessEngineFactory.cpp", "_chess_engine_factory_8cpp.html", null ],
    [ "ChessEngineFactory.h", "_chess_engine_factory_8h.html", [
      [ "ChessEngineFactory", "classpkchessengine_1_1_chess_engine_factory.html", "classpkchessengine_1_1_chess_engine_factory" ]
    ] ]
];