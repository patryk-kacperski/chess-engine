var structpkchessengine_1_1_move =
[
    [ "board", "structpkchessengine_1_1_move.html#ab6fa19b38e09ba56c45db1b2e91bb995", null ],
    [ "destination", "structpkchessengine_1_1_move.html#a94a321e8a2e0d10fdf3b0a8879e66c57", null ],
    [ "origin", "structpkchessengine_1_1_move.html#aa56371b4045249707b4c7e40faf7d7c9", null ],
    [ "side", "structpkchessengine_1_1_move.html#af3c4e83e1e63e66195ddf60fa217f843", null ]
];