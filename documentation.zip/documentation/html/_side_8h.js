var _side_8h =
[
    [ "Side", "_side_8h.html#a496631323ab9117e0e11b41ef4c9c7ea", [
      [ "kWhite", "_side_8h.html#a496631323ab9117e0e11b41ef4c9c7eaad368dbde55a733c6dde5a20566d50736", null ],
      [ "kBlack", "_side_8h.html#a496631323ab9117e0e11b41ef4c9c7eaac5157738e8808c557e6cac46c034a2db", null ]
    ] ]
];