var structpkchessengine_1_1_promotion_info =
[
    [ "PromotionInfo", "structpkchessengine_1_1_promotion_info.html#ae7760bbef9ff0b4432dbb0e625942285", null ],
    [ "PromotionInfo", "structpkchessengine_1_1_promotion_info.html#ad2af09646c490d9f2a3d0216458d9e87", null ],
    [ "position", "structpkchessengine_1_1_promotion_info.html#af2b4e2a29255b3ef18b7fd8e33886f07", null ],
    [ "shouldPromote", "structpkchessengine_1_1_promotion_info.html#a856de972ca766d26f3642e723ee25c2c", null ]
];