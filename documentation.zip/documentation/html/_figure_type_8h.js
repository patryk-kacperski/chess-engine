var _figure_type_8h =
[
    [ "FigureType", "_figure_type_8h.html#afd39499bccd679fdd0a65d74bea898fd", [
      [ "kPawn", "_figure_type_8h.html#afd39499bccd679fdd0a65d74bea898fda5187644c2338a06f6ac916ab31c64ea9", null ],
      [ "kRook", "_figure_type_8h.html#afd39499bccd679fdd0a65d74bea898fdabdd7c9b6be196c66eb64f17ad5ed446f", null ],
      [ "kBishop", "_figure_type_8h.html#afd39499bccd679fdd0a65d74bea898fdac082ad689c95af3e260b698b6288104a", null ],
      [ "kKnight", "_figure_type_8h.html#afd39499bccd679fdd0a65d74bea898fda69ac08d402267ebb8f8ed16252a29431", null ],
      [ "kKing", "_figure_type_8h.html#afd39499bccd679fdd0a65d74bea898fdaace1f8d5899e0335f727b664001dd6b2", null ],
      [ "kQueen", "_figure_type_8h.html#afd39499bccd679fdd0a65d74bea898fda29102b2d5303ff2b486596436e7b4030", null ],
      [ "kNone", "_figure_type_8h.html#afd39499bccd679fdd0a65d74bea898fda35c3ace1970663a16e5c65baa5941b13", null ]
    ] ]
];