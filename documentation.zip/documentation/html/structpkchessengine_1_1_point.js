var structpkchessengine_1_1_point =
[
    [ "Point", "structpkchessengine_1_1_point.html#adb02ae26fa9305e1450a11d360c44b31", null ],
    [ "x", "structpkchessengine_1_1_point.html#a5ebb89e2a7c3564fa1fffabef7ceaaab", null ],
    [ "y", "structpkchessengine_1_1_point.html#a40b454eabac20d6765b13ddb0d438ebc", null ]
];