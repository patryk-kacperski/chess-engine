var files_dup =
[
    [ "board", "dir_7149141a7e3af1ee95dfb0598e371427.html", "dir_7149141a7e3af1ee95dfb0598e371427" ],
    [ "engine", "dir_996f45160da62e1a3d7f6046fad68f51.html", "dir_996f45160da62e1a3d7f6046fad68f51" ],
    [ "pieces", "dir_253bf3c38e8369f20550042cfc2ed392.html", "dir_253bf3c38e8369f20550042cfc2ed392" ],
    [ "util", "dir_23ec12649285f9fabf3a6b7380226c28.html", "dir_23ec12649285f9fabf3a6b7380226c28" ],
    [ "validators", "dir_e3818dbe052c35541aa8102ff72444f2.html", "dir_e3818dbe052c35541aa8102ff72444f2" ]
];