var classpkchessengine_1_1_move_validator =
[
    [ "validate", "classpkchessengine_1_1_move_validator.html#a42377d1423af639a151173634482ff70", null ]
];