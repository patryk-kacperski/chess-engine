var dir_7149141a7e3af1ee95dfb0598e371427 =
[
    [ "Board.cpp", "_board_8cpp.html", null ],
    [ "Board.h", "_board_8h.html", [
      [ "Board", "classpkchessengine_1_1_board.html", "classpkchessengine_1_1_board" ]
    ] ]
];