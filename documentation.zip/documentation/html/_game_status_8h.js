var _game_status_8h =
[
    [ "GameStatus", "_game_status_8h.html#ac27c761e0716a1f1cce963d7778f9cf5", [
      [ "kInProgress", "_game_status_8h.html#ac27c761e0716a1f1cce963d7778f9cf5a0d09a587502569598e6e97d5ae834a08", null ],
      [ "kCheck", "_game_status_8h.html#ac27c761e0716a1f1cce963d7778f9cf5a471d5e7d6d3dc4833d65664394b9a448", null ],
      [ "kCheckMate", "_game_status_8h.html#ac27c761e0716a1f1cce963d7778f9cf5a23e7ff3df3892f74f70d8b80f432c79b", null ],
      [ "kStaleMate", "_game_status_8h.html#ac27c761e0716a1f1cce963d7778f9cf5a5521676e044bde7acd91380ede15d884", null ]
    ] ]
];