var searchData=
[
  ['piecetype',['PieceType',['../namespacepkchessengine.html#a944a1fb497e86ffc347afdb3f0f84381',1,'pkchessengine']]],
  ['promotionresult',['PromotionResult',['../namespacepkchessengine.html#a4e36317122fe119d040920d5cad75837',1,'pkchessengine']]]
];
