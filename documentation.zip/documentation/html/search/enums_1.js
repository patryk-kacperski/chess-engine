var searchData=
[
  ['moveresult',['MoveResult',['../namespacepkchessengine.html#aa909bb6eb3b8f00568f0a4ffe1946e9b',1,'pkchessengine']]]
];
