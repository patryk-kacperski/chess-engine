var searchData=
[
  ['shouldpromote',['shouldPromote',['../classpkchessengine_1_1_chess_engine.html#a8ee22a8630cf255c3a77a6f0744ac319',1,'pkchessengine::ChessEngine']]]
];
