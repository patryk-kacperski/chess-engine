var searchData=
[
  ['kingmovevalidator',['KingMoveValidator',['../classpkchessengine_1_1_king_move_validator.html',1,'pkchessengine']]],
  ['knightmovevalidator',['KnightMoveValidator',['../classpkchessengine_1_1_knight_move_validator.html',1,'pkchessengine']]]
];
