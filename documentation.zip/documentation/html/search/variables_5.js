var searchData=
[
  ['type',['type',['../structpkchessengine_1_1_piece_info.html#ae60c29592ea04d596bde9c71f2742dcc',1,'pkchessengine::PieceInfo']]]
];
