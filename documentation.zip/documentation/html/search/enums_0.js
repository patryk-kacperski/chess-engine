var searchData=
[
  ['gamestatus',['GameStatus',['../namespacepkchessengine.html#ac27c761e0716a1f1cce963d7778f9cf5',1,'pkchessengine']]]
];
