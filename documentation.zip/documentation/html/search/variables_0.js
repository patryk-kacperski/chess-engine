var searchData=
[
  ['board',['board',['../structpkchessengine_1_1_move.html#ab6fa19b38e09ba56c45db1b2e91bb995',1,'pkchessengine::Move']]]
];
