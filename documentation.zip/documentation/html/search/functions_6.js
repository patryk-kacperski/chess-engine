var searchData=
[
  ['validate',['validate',['../classpkchessengine_1_1_piece.html#a6c86771da26adbf64b5ca2fea2f9cb2d',1,'pkchessengine::Piece::validate()'],['../classpkchessengine_1_1_move_validator.html#a42377d1423af639a151173634482ff70',1,'pkchessengine::MoveValidator::validate()']]]
];
