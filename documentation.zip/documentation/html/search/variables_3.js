var searchData=
[
  ['position',['position',['../structpkchessengine_1_1_promotion_info.html#af2b4e2a29255b3ef18b7fd8e33886f07',1,'pkchessengine::PromotionInfo']]]
];
