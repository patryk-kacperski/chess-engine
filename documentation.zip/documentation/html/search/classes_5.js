var searchData=
[
  ['queenmovevalidator',['QueenMoveValidator',['../classpkchessengine_1_1_queen_move_validator.html',1,'pkchessengine']]]
];
