var searchData=
[
  ['move',['Move',['../structpkchessengine_1_1_move.html',1,'pkchessengine']]],
  ['movevalidator',['MoveValidator',['../classpkchessengine_1_1_move_validator.html',1,'pkchessengine']]]
];
