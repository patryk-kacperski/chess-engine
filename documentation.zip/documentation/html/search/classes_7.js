var searchData=
[
  ['rookmovevalidator',['RookMoveValidator',['../classpkchessengine_1_1_rook_move_validator.html',1,'pkchessengine']]]
];
