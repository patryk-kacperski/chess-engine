var searchData=
[
  ['bishopmovevalidator',['BishopMoveValidator',['../classpkchessengine_1_1_bishop_move_validator.html',1,'pkchessengine']]],
  ['board',['Board',['../classpkchessengine_1_1_board.html',1,'pkchessengine']]]
];
