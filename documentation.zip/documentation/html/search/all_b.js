var searchData=
[
  ['shouldpromote',['shouldPromote',['../structpkchessengine_1_1_promotion_info.html#a856de972ca766d26f3642e723ee25c2c',1,'pkchessengine::PromotionInfo::shouldPromote()'],['../classpkchessengine_1_1_chess_engine.html#a8ee22a8630cf255c3a77a6f0744ac319',1,'pkchessengine::ChessEngine::shouldPromote()']]],
  ['side',['side',['../structpkchessengine_1_1_move.html#af3c4e83e1e63e66195ddf60fa217f843',1,'pkchessengine::Move::side()'],['../structpkchessengine_1_1_piece_info.html#ab5e303f22f0d4169f21f0d876f4fd560',1,'pkchessengine::PieceInfo::side()'],['../namespacepkchessengine.html#a496631323ab9117e0e11b41ef4c9c7ea',1,'pkchessengine::Side()']]],
  ['side_2eh',['Side.h',['../_side_8h.html',1,'']]]
];
