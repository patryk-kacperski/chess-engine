var searchData=
[
  ['origin',['origin',['../structpkchessengine_1_1_move.html#aa56371b4045249707b4c7e40faf7d7c9',1,'pkchessengine::Move']]]
];
