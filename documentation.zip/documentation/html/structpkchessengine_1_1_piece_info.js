var structpkchessengine_1_1_piece_info =
[
    [ "side", "structpkchessengine_1_1_piece_info.html#ab5e303f22f0d4169f21f0d876f4fd560", null ],
    [ "type", "structpkchessengine_1_1_piece_info.html#ae60c29592ea04d596bde9c71f2742dcc", null ]
];