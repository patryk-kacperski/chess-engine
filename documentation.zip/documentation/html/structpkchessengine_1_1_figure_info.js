var structpkchessengine_1_1_figure_info =
[
    [ "side", "structpkchessengine_1_1_figure_info.html#afc1059e6d436df715e03edfd8d3d490e", null ],
    [ "type", "structpkchessengine_1_1_figure_info.html#a25192e5c812d4e4788f97d94027a9874", null ]
];