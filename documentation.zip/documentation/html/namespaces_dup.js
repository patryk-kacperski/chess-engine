var namespaces_dup =
[
    [ "pkchessengine", "namespacepkchessengine.html", null ]
];